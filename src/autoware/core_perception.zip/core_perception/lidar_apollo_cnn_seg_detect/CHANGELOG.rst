^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package lidar_apollo_cnn_seg_detect
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2019-03-21)
-------------------
* [feature] Baidu's CNN based LiDAR segmentation (`#1800 <https://github.com/CPFL/Autoware/issues/1800>`_)
  * Add build caffe
  * add include apollo files
  * add apollo cnn
  * calculating time
  * * Cleaned node
  * Parametrized inputs
  * Works with custom caffe
  * * Parameterized
  * Works with custom Caffe
  * Removed hard coded params
  * Cleaned up dependencies
  * Added bboxes, labels
  * Minor fixes
  * Custom input topic
  * Added UI, launch file, readme
  * Added Compatibility for Perception Cleanup
  * * Added license messages
  * Updated readme
  * Added extra instructions
  * Fix markdown
* Contributors: Abraham Monrroy Cano
