^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package lidar_point_pillars
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2019-03-21)
-------------------
* [Feature]PointPillars (`#2029 <https://github.com/CPFL/Autoware/issues/2029>`_)
* Contributors: Kosuke Murakami
