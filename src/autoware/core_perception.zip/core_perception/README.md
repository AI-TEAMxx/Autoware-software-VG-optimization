# core_perception
Autoware packages related to understanding the state of the world (perception, localisation, object recognition, etc.).

www.autoware.org
